module game_state(
    input logic clk, clk_1ms, reset,
    input logic [3:0] p1_score, p2_score,
    input logic [59:0] timer,
    output logic [1:0] game_state
);

    logic [3:0] win = 4'b1001; // No. of goals to win

    always_ff @(posedge clk) begin
        if (!reset)
            game_state <= 2'b00;
        else begin
            if (p1_score == win)
                game_state <= 2'b10; // p1 won
            else if (p2_score == win)
                game_state <= 2'b11; // p2 won
            else if (timer > 60) begin
                if (p1_score > p2_score)
                    game_state <= 2'b10; // p1 won
                else if (p1_score == p2_score)
                    game_state <= 2'b01; // still playing
                else
                    game_state <= 2'b11; // p2 won
            end
            else
                game_state <= 2'b01; // playing
        end
    end
endmodule
