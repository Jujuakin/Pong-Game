module seven_seg (
    input logic clk, clk_1ms, reset,
    input logic [3:0] p1_score, p2_score,
    input logic [9:0] x, y,
    output reg [6:0] seg1, seg2
);

    logic [3:0] score_display_p1, score_display_p2; 

    localparam int CENTER_X = 320; 
    localparam int CENTER_Y = 240; 
    
    always_ff @(posedge clk) begin
        if (reset) begin
            score_display_p1 <= 4'b1111; 
        end else begin
            if (x >= CENTER_X - 20 && x <= CENTER_X + 20 && y >= CENTER_Y - 20 && y <= CENTER_Y + 20) begin
                score_display_p1 <= p1_score;
            end else begin
                score_display_p1 <= 4'b1111;
            end
        end
    end

    always_ff @(posedge clk) begin
        if (reset) begin
            score_display_p2 <= 4'b1111; 
        end else begin
            if (x >= CENTER_X - 20 && x <= CENTER_X + 20 && y >= CENTER_Y - 20 && y <= CENTER_Y + 20) begin
                score_display_p2 <= p2_score;
            end else begin
                score_display_p2 <= 4'b1111;
            end
        end
    end

    always_comb begin
        case (p1_score)
            4'b0000 : seg1 = 7'b1000000;  // 0
            4'b0001 : seg1 = 7'b1111001;  // 1
            4'b0010 : seg1 = 7'b0100100;  // 2
            4'b0011 : seg1 = 7'b0110000;  // 3
            4'b0100 : seg1 = 7'b0011001;  // 4
            4'b0101 : seg1 = 7'b0010010;  // 5
            4'b0110 : seg1 = 7'b0000010;  // 6
            4'b0111 : seg1 = 7'b1111000;  // 7
            4'b1000 : seg1 = 7'b0000000;  // 8
            4'b1001 : seg1 = 7'b0010000;  // 9
            default : seg1 = 7'b1111111;
        endcase
        
        case (p2_score)
            4'b0000 : seg2 = 7'b1000000;  // 0
            4'b0001 : seg2 = 7'b1111001;  // 1
            4'b0010 : seg2 = 7'b0100100;  // 2
            4'b0011 : seg2 = 7'b0110000;  // 3
            4'b0100 : seg2 = 7'b0011001;  // 4
            4'b0101 : seg2 = 7'b0010010;  // 5
            4'b0110 : seg2 = 7'b0000010;  // 6
            4'b0111 : seg2 = 7'b1111000;  // 7
            4'b1000 : seg2 = 7'b0000000;  // 8
            4'b1001 : seg2 = 7'b0010000;  // 9
            default : seg2 = 7'b1111111;
        endcase
    end
endmodule
