module ball (
    input logic clk, clk_1ms, reset,
    input logic [9:0] x, y,
    output logic ball_on,
    output logic [11:0] rgb_ball,
    input logic [9:0] x_paddle1, x_paddle2, y_paddle1, y_paddle2,
    output reg [3:0] p1_score, p2_score,
    input logic [1:0] game_state
);

    localparam int Hmax = 640;
    localparam int Vmax = 480;
    
    localparam int ball_width = 12;
    localparam int ball_height = 12;

    localparam int paddlewidth = 20;
    localparam int paddleheight = 80;
    
    int dx = 1, dy = 1;
    
    logic [9:0] x_ball, y_ball;
        
    always_ff @(posedge clk_1ms) begin
        if (!reset) begin
            x_ball <= Hmax/2;
            y_ball <= Vmax/2;
            p1_score <= 0;
            p2_score <= 0;    
        end
        else if (game_state == 2'b01) begin
            // EDGES
            if (y_ball == (ball_height/2)+1) //Top starting +1
                dy = -dy;
            if (y_ball == (Vmax-(ball_height/2)-1)) //Bottom ending -1
                dy = -dy;

            // PADDLE COLLISION
            if (x_ball > (x_paddle2-ball_width/2) && y_ball > (y_paddle2 - paddleheight/2) && y_ball < (y_paddle2 + paddleheight/2))
                dx = -dx;
            if (x_ball < (x_paddle1+ball_width/2) && y_ball > (y_paddle1 - paddleheight/2) && y_ball < (y_paddle1 + paddleheight/2))
                dx = -dx;
            
    
            if (x_ball == (Hmax -ball_width/2)) begin //Paddle2 lost
                x_ball <= Hmax/2;
                y_ball <= Vmax/2;
                dy = -dy;
                dx = -dx; // change the direction of ball
                p1_score <= p1_score + 1;
            end
            else if (x_ball == 0) begin //Paddle1 lost
                x_ball <= Hmax/2;
                y_ball <= Vmax/2;
                dy = -dy;
                dx = -dx;
                p2_score <= p2_score + 1;
            end
            else begin
                x_ball <= x_ball + dx;
                y_ball <= y_ball - dy;    
            end
        end
        else begin //IF game is not being played
            x_ball <= x_ball;
            y_ball <= y_ball;
        end    
    end
        
    assign ball_on = (x >= x_ball-(ball_width/2) && x <= x_ball+(ball_width/2) && y >= y_ball-(ball_height/2) && y <= y_ball+(ball_height/2)) ? 1'b1 : 1'b0;
    
    assign rgb_ball = 12'b111111111111; // Silver = 12'b101110111011, skyblue=12'b100011001110, Gold =12'b111111010000
    
endmodule
