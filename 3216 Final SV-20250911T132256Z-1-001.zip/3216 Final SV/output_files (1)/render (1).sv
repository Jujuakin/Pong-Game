module render(
    input logic clk, reset, sw1,
    input logic [9:0] x, y, // position of point
    input logic video_on,
    output logic [11:0] rgb,
    input logic clk_1ms,
    input logic paddle1_on, paddle2_on, ball_on,
    input logic [11:0] rgb_paddle1, rgb_paddle2, rgb_ball,
    input logic [1:0] game_state,
    input logic [3:0] p1_score, p2_score,
    output logic [7:0] score1,
    output logic [7:0] score2
);

    logic [11:0] rgb_reg;

    localparam int Hmax = 640;
    localparam int Vmax = 480;
    localparam int zero = 0;

    localparam int X_blocksize = 50;
    localparam int Y_blocksize = 50;
    logic [9:0] x_block_left = X_blocksize / 2; // starting position of left block
    logic [9:0] x_block_right = Hmax - X_blocksize / 2; // starting position of right block
    logic [9:0] y_block = Vmax - Y_blocksize / 2; // starting position of both blocks

    logic [3:0] last_p1_score = 0, last_p2_score = 0;
    logic [11:0] corner_color_left = {4'h6, 8'hF9}; // light blue
    logic [11:0] corner_color_right = {4'h6, 8'hF9}; // light blue

    always_ff @(posedge clk) begin
        if (!reset) begin
            rgb_reg <= 12'h000;
            corner_color_left <= 12'h00F;
            corner_color_right <= 12'h00F;
            last_p1_score <= 0;
            last_p2_score <= 0;
        end else begin
            if (game_state == 2'b01) begin
                if (paddle1_on) begin
                    rgb_reg <= rgb_paddle1;
                end else if (paddle2_on) begin
                    rgb_reg <= rgb_paddle2;
                end else if (ball_on) begin
                    rgb_reg <= rgb_ball;
                end else begin
                    rgb_reg <= 12'h000;
                end
            end else if (game_state == 2'b10) begin
                rgb_reg <= rgb_paddle1;
            end else if (game_state == 2'b11) begin
                rgb_reg <= rgb_paddle2;
            end else begin
                rgb_reg <= 12'h000;
            end

            if (p1_score != last_p1_score) begin
                corner_color_left <= {corner_color_left[11:8], corner_color_left[7:2] + 4'd1}; // increase blue component by 1
                last_p1_score <= p1_score;
            end

            if (p2_score != last_p2_score) begin
                corner_color_right <= {corner_color_right[11:8], corner_color_right[7:2] + 4'd1}; // increase blue component by 1
                last_p2_score <= p2_score;
            end

            if (sw1 == 1) begin
                // set the color of the left block
                if (x < X_blocksize && y >= Vmax - Y_blocksize) begin
                    rgb_reg[11:0] <= corner_color_left;
                end

                // set the color of the right block
                if (x >= Hmax - X_blocksize && y >= Vmax - Y_blocksize) begin
                    rgb_reg[11:0] <= corner_color_right;
                end

                // Slow down darkening of blue blocks
                if (corner_color_right[7:4] > 4'd1) begin
                    corner_color_right[7:4] <= corner_color_right[7:4] - 4'd1;
                end

                if (corner_color_left[7:4] > 4'd1) begin
                    corner_color_left[7:4] <= corner_color_left[7:4] - 4'd1;
                end
            end
        end
    end

    assign rgb = (video_on) ? rgb_reg : 12'b0;
endmodule
