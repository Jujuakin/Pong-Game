//module paddle(
//	input clk_1ms,reset, 
//	input button, button1, button2, button3,
//	input [9:0] x, y,
//	output paddle1_on,paddle2_on,
//	output [11:0] rgb_paddle1, rgb_paddle2,
//	output reg [9:0] x_paddle1 = L_position + (paddlewidth/2),
//	output reg [9:0] y_paddle1 = V_active/2,
//	output reg [9:0] x_paddle2 = H_active-(R_position + (paddlewidth/2)),
//	output reg [9:0] y_paddle2 = V_active/2
//	);
//	
//	wire reset_n;
//   wire clk1, spi_clk, spi_clk_out;
//
//   localparam SPI_CLK_FREQ  = 200;  // SPI Clock (Hz)
//   localparam UPDATE_FREQ   = 1;    // Sampling frequency (Hz)
//   wire data_update;
//   wire [15:0] data_x, data_y;
//	integer direction = 0;
//	
//pll ip_inst (
//   .inclk0 ( clk ),
//   .c0 ( clk1 ),                 // 25 MHz, phase   0 degrees
//   .c1 ( spi_clk ),             //  2 MHz, phase   0 degrees
//   .c2 ( spi_clk_out )          //  2 MHz, phase 270 degrees
//   );
//	
//spi_control #(     // parameters
//      .SPI_CLK_FREQ   (SPI_CLK_FREQ),
//      .UPDATE_FREQ    (UPDATE_FREQ))
//   spi_ctrl (      // port connections
//      .reset_n    (reset_n),
//      .clk        (clk1),
//      .spi_clk    (spi_clk),
//      .spi_clk_out(spi_clk_out),
//      .data_update(data_update),
//      .data_x     (data_x),
//      .data_y     (data_y),
//      .SPI_SDI    (GSENSOR_SDI),
//      .SPI_SDO    (GSENSOR_SDO),
//      .SPI_CSN    (GSENSOR_CS_N),
//      .SPI_CLK    (GSENSOR_SCLK),
//      .interrupt  (GSENSOR_INT)
//   );
//	
////	localparam H_active = 640;
////	localparam V_active = 480;
////	
////	localparam paddlewidth = 15;
////	localparam paddleheight = 60;
////	
////	localparam L_position = 20;
////	localparam R_position = 20;
////	reg [31:0] data_xInitial = 0;
////	reg [31:0] data_yInitial = 0;
////	integer buffer = 60;
////	
////		
////	always @ (posedge clk_1ms)
////	begin
////		if(!reset)
////		begin
////			x_paddle1 <= L_position + (paddlewidth/2);
////			y_paddle1 <= V_active/2;
////		end
////		else if (!button && y_paddle1-(paddleheight/2) > 0)
////			y_paddle1 <= y_paddle1-1;
////		else if (!button1 && y_paddle1+(paddleheight/2) < V_active)
////			y_paddle1 <= y_paddle1+1;
////		else y_paddle1 <= y_paddle1;
////	end
////	
////	assign paddle1_on = (x >= x_paddle1-(paddlewidth/2) && x <= x_paddle1+(paddlewidth/2) && y >= y_paddle1-(paddleheight/2) && y < y_paddle1+(paddleheight/2))?1:0;
////
////	assign rgb_paddle1 = 12'b000011110000; 
////	
////	//Second padlle
////	always @ (posedge clk_1ms)
////	begin
////		if(!reset)
////		begin	
////			data_xInitial = 0;
////			data_yInitial = 0;
////			x_paddle2 <= H_active-(R_position + (paddlewidth/2));
////			y_paddle2 <= V_active/2;
////		end
////		else if (data_x[13] && y_paddle2-(paddleheight/2) > 0)
////			y_paddle2 <= y_paddle2-1;
////		else if (data_x[13] && y_paddle2+(paddleheight/2) < V_active )
////			y_paddle2 <= y_paddle2+1;
////		else y_paddle2 <= y_paddle2;
////				
////		
////
////	end
////	
////	
////	assign paddle2_on = (x >= x_paddle2-(paddlewidth/2) && x <= x_paddle2+(paddlewidth/2) && y >= y_paddle2-(paddleheight/2) && y < y_paddle2+(paddleheight/2))?1:0;
////	assign rgb_paddle2 = 12'b110000001100; //orange =12'bb111101110000
//endmodule